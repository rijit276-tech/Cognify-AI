# Cognify AI

A Pen created on CodePen.

Original URL: [https://codepen.io/Rijit-Das/pen/jEMVKPr](https://codepen.io/Rijit-Das/pen/jEMVKPr).

